//
//  AppDelegate.swift
//  Qantas
//
//  Created by mac05 on 22/07/19.
//  Copyright © 2019 Qantas. All rights reserved.
//

import Cocoa
import SafariServices.SFSafariApplication

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }
    
    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }
    
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true;
    }
    
    
    @IBAction func enableAction(_ sender: NSMenuItem) {
        SFSafariApplication.showPreferencesForExtension(withIdentifier: "com.qantas.app-Extension") { error in
            if let _ = error {
                // Insert code to inform the user that something went wrong.
            }
        }

    }
    
    
}
