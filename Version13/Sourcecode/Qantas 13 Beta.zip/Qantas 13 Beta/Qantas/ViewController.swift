//
//  ViewController.swift
//  Qantas
//
//  Created by mac05 on 22/07/19.
//  Copyright © 2019 Qantas. All rights reserved.
//

import Cocoa
import SafariServices.SFSafariApplication

class ViewController: NSViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //MARK: - Button Actions
    // To Open Safari Preferences
    @IBAction func openSafariExtensionPreferences(_ sender: AnyObject?) {
        SFSafariApplication.showPreferencesForExtension(withIdentifier: "com.qantas.app-Extension") { error in
            if let _ = error {
                // Insert code to inform the user that something went wrong.
            }
        }
    }
    
    // To Open Installation Success Url in Safari
    @IBAction func completeSetupAction(_ sender: Any) {
        let url = URL(string:Config.SHOPPING_URL_BASE + "/points-prompter-success")!
        NSWorkspace.shared.open([url], withAppBundleIdentifier:"com.apple.Safari", options: [], additionalEventParamDescriptor: nil, launchIdentifiers: nil)
    }
    
}
