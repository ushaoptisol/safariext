//
//  Config.swift
//  Qantas Extension
//
//  Created by mac05 on 23/07/19.
//  Copyright © 2019 Qantas. All rights reserved.
//

import Foundation

struct Config {
    static let SHOPPING_URL_BASE = "https://shopping.qantas.com"
    static let QANTAS_URL = "https://www.qantas.com"
    static let QUERY_URL_BASE = "https://api.services.qantasloyalty.com/shopping/query"
    static let SHO_ACCESS_TOKEN_COOKIE_NAME = "qs_access_token"
    static let URL_GOOGLE = "https://www.google.com"
    static let SYNC_DATA_EVERY = 1 * 60 * 60 * 1000
    static let LOGOUT_URL =  SHOPPING_URL_BASE + "/logout"    
}
