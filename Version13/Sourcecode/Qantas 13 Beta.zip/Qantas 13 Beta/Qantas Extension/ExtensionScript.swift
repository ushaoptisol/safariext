//
//  ExtensionScript.swift
//  Qantas Extension
//
//  Created by mac05 on 26/07/19.
//  Copyright © 2019 Qantas. All rights reserved.
//

import Foundation
import Alamofire
import ObjectMapper

public var urlHistory:[String] = []

class ExtensionScript: NSObject {
    
    public static var merchantUrlToMerchantId : [String : AnyObject] = [:]
    
    // Get all sites list API
    class func refreshData(completion : @escaping ()->()){
        let query = "query{ getAfLinks " +
            "allMerchants {" +
            "toolbar_permitted " +
            "websiteUrl " +
            "merchantId " +
            "merchantIdOLM " +
            "merchantStatus " +
            "isVisible " +
            "rebate {" +
            " rebate_user " +
            "} " +
            "details {" +
            "   info_special_terms " +
            "}" +
            "promoted {" +
            "   prepend_special_terms" +
            "}" +
        "}}"
        
        let url = URL(string: Config.QUERY_URL_BASE)!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = HTTPMethod.post.rawValue
        urlRequest.setValue("application/json", forHTTPHeaderField: "Accept")
        urlRequest.setValue("application/json;charset=UTF-8", forHTTPHeaderField: "Content-Type")
        let parameters: Parameters = ["query": query]
        do {
            urlRequest.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
        }catch let error {
            print(error.localizedDescription)
        }
        
        
        Alamofire.request(urlRequest).responseString {response in
            if response.result.isSuccess {
                let responseData = self.convertToDictionary(text:response.value!)
                let queryResult:MerchantData = Mapper<MerchantData>().map(JSONObject: responseData!["data"])!
                var merchantCache : [String : Any] = [:]
                let linkList = queryResult.getAfLinks ?? []
                
                for m:Merchant in queryResult.allMerchants ?? [] {
                    merchantCache[m.merchantId!] = m.toJSON()
                    let urls = m.websiteUrl ?? []
                    for url in urls {
                        self.createMerchantUrlToMapping(url: url, merchantId: m.merchantId!)
                    }
                }
                LocalStorage.setMerchantDataToLocalStorage(data: merchantCache as AnyObject)
                LocalStorage.setMerchantsUrlMap(data: self.merchantUrlToMerchantId as AnyObject)
                LocalStorage.setStandDownLinks(data: linkList as AnyObject)
            }else {
                print("API Error", response.error?.localizedDescription ?? "")
            }
            completion()
        }
    }
    
    class func createMerchantUrlToMapping(url : String, merchantId : String) {
        let lastChar = url.last!
        var length = url.count
        if lastChar == "/" {
            length = url.count - 1
        }
        let parsedUrl = url[0..<length]
        var tempUrl = ""
        if parsedUrl.contains("https://") {
            tempUrl = parsedUrl.replacingOccurrences(of: "https://", with: "")
        }else {
            tempUrl = parsedUrl.replacingOccurrences(of: "http://", with: "")
        }
        var endOfDomain = parsedUrl.count
        
        if tempUrl.range(of: "/") != nil {
            if let idx = tempUrl.firstIndex(of: "/") {
                let distance = tempUrl.distance(from: tempUrl.startIndex, to: idx)
                endOfDomain = distance
                if parsedUrl.contains("https://") {
                    endOfDomain = endOfDomain + 8
                }else {
                    endOfDomain = endOfDomain + 7
                }
            }
        }
        let hostUrl = parsedUrl[0..<endOfDomain]
        if hostUrl != url {
            merchantUrlToMerchantId[hostUrl] = ["startsWith" : url, "merchantId" : merchantId] as AnyObject
        }else {
            merchantUrlToMerchantId[hostUrl] = ["merchantId" : merchantId] as AnyObject
        }
        
    }
    
    class func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    
    class func GetMerchantDataForGoogle(url: String) -> [String: Any] {
        var merchantData = getMerchantData()
        let merchantsUrlmap = LocalStorage.getMerchantsUrlMap()
        merchantData.merge(dict: ["merchantsUrlmap" : merchantsUrlmap!])
        return ["merchantData" : merchantData]
    }
    

    class func getMerchantData() -> [String: Any] {
        if LocalStorage.getMerchantDataFromLocalStorage() != nil {
            let localMerchantData = LocalStorage.getMerchantDataFromLocalStorage() as! [String:Any]
            let lastSyncTimestamp = localMerchantData["timestamp"] as! Int64
            let timestampDiff = Date().getTime() - lastSyncTimestamp
            if timestampDiff <= Config.SYNC_DATA_EVERY {
                return localMerchantData["data"] as! [String : Any]
            }else {
                self.refreshData {
                    getMerchantData()
                }
            }
        }else {
            self.refreshData {
                getMerchantData()
            }
        }
        return [:]
    }
    
    class func onMerchantDetected(url: String) -> [String: Any] {
        let merchantData = getMerchantData()
        let matchedMerchantId = getMerchantIdForUrl(url: url)
        let token = LocalStorage.getAccessToken()
        var isDismissed = false
        var isTracking = false
        var isPermitted = false
        
        if (matchedMerchantId != "" && !merchantData.isEmpty) {
            let currentMerchant = merchantData[matchedMerchantId] as! [String:AnyObject]
            let clickData = LocalStorage.getMerchantClickData(merchantId: matchedMerchantId) as? [String:Int64]
            if clickData != nil {                
                let dismissTimeStamp = clickData!["lastClosedTimestamp"] ?? 0
                let dismissValue = dismissTimeStamp + Int64(DISMISS_TIMEOUT)
                if dismissValue > Date().getTime() {
                    isDismissed = true
                }

                
                let trackTimeStamp = clickData!["trackingTimestamp"] ?? 0
                let trackValue = trackTimeStamp + Int64(TRACKING_DURATION)
                if trackValue > Date().getTime() {
                    isTracking = true
                }
            }
            
            isPermitted = currentMerchant["toolbar_permitted"] as! Bool && currentMerchant["isVisible"] as! Bool
            var newMerchantData = ["isTracking" : isTracking, "isDismissed" : isDismissed, "isPermitted" : isPermitted] as [String:AnyObject]
            newMerchantData.merge(dict: currentMerchant)
            let returnData = ["merchantData" : newMerchantData, "token" : token]
            return returnData
        }else {
            let returnData = ["merchantData" : ["isTracking" : isTracking, "isDismissed" : isDismissed, "isPermitted" : isPermitted], "token" : token] as [String : Any]
            return returnData
        }
        
    }
    
    class func getMerchantIdForUrl(url: String) -> String {
        var tempUrl = ""
        if url.contains("https://") {
            tempUrl = url.replacingOccurrences(of: "https://", with: "")
        }else {
            tempUrl = url.replacingOccurrences(of: "http://", with: "")
        }
        var endOfDomain = url.count
        
        if tempUrl.range(of: "/") != nil {
            if let idx = tempUrl.firstIndex(of: "/") {
                let distance = tempUrl.distance(from: tempUrl.startIndex, to: idx)
                endOfDomain = distance
                if url.contains("https://") {
                    endOfDomain = endOfDomain + 8
                }else {
                    endOfDomain = endOfDomain + 7
                }
            }
        }
        let hostUrl = url[0..<endOfDomain]
        let merchantData = LocalStorage.getMerchantsUrlMap() as? [String:AnyObject]
        if merchantData != nil {
            let merchantMapping = merchantData![hostUrl] as? [String:AnyObject]
            if merchantMapping != nil {
                if (merchantMapping?["startsWith"] != nil) {
                    if (url.starts(with: merchantMapping?["startsWith"] as! String)) {
                        return merchantMapping!["merchantId"] as! String
                    }else{
                        return ""
                    }
                }else {
                    return merchantMapping!["merchantId"] as! String
                }
            }
        }
        return ""
    }
    
    class func Logout() {
        urlHistory.removeAll()
        let domain = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: domain)
        UserDefaults.standard.synchronize()
        UserDefaults.standard.set(true, forKey: IS_FIRST_TIME)
    }
    
    class func handleClosedClicked(merchantId: String) {
        if merchantId != "" {
            LocalStorage.setMerchantClosed(merchantId: merchantId)
        }
    }
    
    class func detectSHOTracking(activeUrl:String) {
        if urlHistory.count > 0 {
            let matchedMerchantId = getMerchantIdForUrl(url: activeUrl)
            let redirectedFromShopping = urlHistory.filter { $0.starts(with: "\(Config.SHOPPING_URL_BASE)/shop?id=\(matchedMerchantId)") || $0.starts(with: "\(Config.SHOPPING_URL_BASE)/login/\(matchedMerchantId)") }
            if (redirectedFromShopping.count != 0) {
                LocalStorage.setMerchantTracking(merchantId: matchedMerchantId)
            }
        }
    }
}
