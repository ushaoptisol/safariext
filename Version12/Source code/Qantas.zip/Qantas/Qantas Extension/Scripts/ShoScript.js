var dvclose = document.getElementsByClassName("sho-close-button");
dvclose.onclick = function() {
    var modal = document.getElementById("sho-main");
    modal.style.display = "none";
}
function ToggleTerms() {
    var dvtermdets = document.getElementById("sho-term-details");
    dvtermdets.classList.toggle("sho-hidden");
}
function CloseShopopup() {
    var modal = document.getElementById("sho-main");
    modal.style.display = "none";
}
function OpenTab(url) {
    window.open(url, "_self");
}
