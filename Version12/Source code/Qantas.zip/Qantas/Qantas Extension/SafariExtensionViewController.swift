//
//  SafariExtensionViewController.swift
//  Qantas Extension
//
//  Created by mac05 on 22/07/19.
//  Copyright © 2019 Qantas. All rights reserved.
//

import SafariServices
import ObjectMapper

class SafariExtensionViewController: SFSafariExtensionViewController {
    
    var selectedMerchantId = ""
    @IBOutlet weak var baseScrollView: NSScrollView!
    @IBOutlet weak var loginView: NSView!
    @IBOutlet weak var userNameLbl: NSTextField!
    @IBOutlet weak var logoutBtn: NSButton!
    @IBOutlet weak var contentLbl: NSTextField!
    @IBOutlet weak var loginBtn: NSButton!
    @IBOutlet weak var termsBtn: NSButton!
    @IBOutlet weak var termsView: NSView!
    @IBOutlet weak var termsTitle: NSTextField!
    @IBOutlet weak var closeBtn: NSButton!
    @IBOutlet var termsTextView: NSTextView!
    @IBOutlet weak var termsHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var termsBtnHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var storesBtn: NSButton!
    @IBOutlet weak var faqBtn: NSButton!
    @IBOutlet weak var contentVerticalConstraint: NSLayoutConstraint!
    @IBOutlet weak var termsVerticalContraint: NSLayoutConstraint!
    @IBOutlet weak var loginBtnHeightConstraint: NSLayoutConstraint!
    
     static let shared = SafariExtensionViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.wantsLayer = true
        logoutBtn.attributedTitle = getAttributedString(str: "Log out", fontSize: 12.0, isWhiteTextColor: false, isUnderLine: true, textAlignment: .center)
        termsBtn.attributedTitle = getAttributedString(str: "Terms & conditions", fontSize: 12.0, isWhiteTextColor: false, isUnderLine: true, textAlignment: .center)
        termsTitle.attributedStringValue = getAttributedString(str: "Terms & conditions", fontSize: 14.0, isWhiteTextColor: false, isUnderLine: false, textAlignment: .center)
        storesBtn.attributedTitle = getAttributedString(str: "A-Z stores", fontSize: 14.0, isWhiteTextColor: false, isUnderLine: true, textAlignment: .center)
        faqBtn.attributedTitle = getAttributedString(str: "FAQs", fontSize: 14.0, isWhiteTextColor: false, isUnderLine: true, textAlignment: .center)
        closeBtn.attributedTitle = getAttributedString(str: "Close", fontSize: 12.0, isWhiteTextColor: false, isUnderLine: true, textAlignment: .center)
    }
    
    override func viewWillAppear() {
        faqBtn.layer?.backgroundColor =  NSColor(red:0.93, green:0.93, blue:0.93, alpha:1.0).cgColor
        storesBtn.layer?.backgroundColor =  NSColor(red:0.93, green:0.93, blue:0.93, alpha:1.0).cgColor
        termsView.layer?.backgroundColor =  NSColor(red:0.93, green:0.93, blue:0.93, alpha:1.0).cgColor
        termsTextView.backgroundColor = NSColor.white
        userNameLbl.backgroundColor = NSColor.white
        termsTextView.backgroundColor = NSColor(red:0.93, green:0.93, blue:0.93, alpha:1.0)
        termsHeightConstraint.constant = 0
        termsView.isHidden = true

        SFSafariApplication.getActiveWindow { (activeWindow) in
            activeWindow?.getActiveTab(completionHandler: { (activeTab) in
                activeTab?.getActivePage(completionHandler: { (activePage) in
                    activePage?.getPropertiesWithCompletionHandler({ (properties) in
                        let activeUrl = properties?.url?.absoluteString ?? ""
                        self.HandlePopoverEvent(url: activeUrl)
                    })
                })
            })
        }
    }
    
    func HandlePopoverEvent(url: String) {
        let merchantData = ExtensionScript.getMerchantData()
        let matchedMerchantId = ExtensionScript.getMerchantIdForUrl(url: url)
        let token = LocalStorage.getAccessToken()
        let currentMerchant = merchantData[matchedMerchantId] as? [String:AnyObject]

        if (matchedMerchantId != "" && currentMerchant != nil) {
            let clickData = LocalStorage.getMerchantClickData(merchantId: matchedMerchantId) as? [String:Int64]
            var isTracking = false
            if clickData != nil {
                let trackTimeStamp = clickData!["trackingTimestamp"] ?? 0
                let trackValue = trackTimeStamp + Int64(TRACKING_DURATION)
                if trackValue > Date().getTime() {
                    isTracking = true
                }
            }
            

            let merchantModel = Mapper<Merchant>().map(JSONObject: currentMerchant) as! Merchant

            if isTracking && (token["isValidToken"] as! Bool) {
                CreatePopover(PopoverName: "OfferActivated", currentMerchant: merchantModel, token: token)
            }else if (!(token["isValidToken"] as! Bool)) {
                CreatePopover(PopoverName: "LoginMerchant", currentMerchant: merchantModel, token: token)
            }else {
                CreatePopover(PopoverName: "ActivateOffer", currentMerchant: merchantModel, token: token)
            }
        }else if (token["isValidToken"] as! Bool){
            CreatePopover(PopoverName: "Logged", currentMerchant: nil, token: token)
        }else {
            CreatePopover(PopoverName: "Login", currentMerchant: nil, token: token)
        }
    }
    
    func CreatePopover(PopoverName : String, currentMerchant: Merchant?, token: [String:AnyObject]) {
        DispatchQueue.main.async {
            switch PopoverName {
            case "ActivateOffer":
                let points = "\(currentMerchant?.rebate?.rebate_user ?? 0)"
                let details = currentMerchant?.details?.first?.info_special_terms ?? ""
                self.selectedMerchantId = currentMerchant?.merchantId ?? ""
                let text = "Hi, \(token["firstName"] as! String)"
                let maintext = "Earn \(points) points per $1 spent" as NSString
                self.contentLbl.attributedStringValue = self.addBoldText(fullString: maintext, boldPartOfString: "\(points) points" as NSString)
                self.userNameLbl.attributedStringValue = self.getAttributedString(str: text, fontSize: 12.0, isWhiteTextColor: false, isUnderLine: false, textAlignment: .right)
                self.termsTextView.textStorage?.setAttributedString(self.getAttributedString(str: details, fontSize: 11.0, isWhiteTextColor: false, isUnderLine: false, textAlignment: .natural))

                self.loginBtn.attributedTitle = self.getAttributedString(str: "EARN QANTAS POINTS", fontSize: 14.0, isWhiteTextColor: true, isUnderLine: false, textAlignment: .center)
                self.loginBtn.imagePosition = .noImage
                self.loginBtn.layer?.backgroundColor = NSColor(red:0.89, green:0.00, blue:0.00, alpha:1.0).cgColor
                self.loginBtn.tag = 100
                self.loginView.isHidden = false
                self.termsBtn.isHidden = false
                self.loginBtn.isHidden = false
                self.contentVerticalConstraint.constant = 10
                self.termsVerticalContraint.constant = 5
                self.termsBtnHeightConstraint.constant = 20
                self.loginBtnHeightConstraint.constant = 40
                self.preferredContentSize = NSSize(width:250, height:220)
                break
            case "OfferActivated":
                let points = "\(currentMerchant?.rebate?.rebate_user ?? 0)"
                let details = currentMerchant?.details?.first?.info_special_terms ?? ""
                self.selectedMerchantId = currentMerchant?.merchantId ?? ""
                let text = "Hi, \(token["firstName"] as! String)"
                let maintext = "Earn \(points) points per $1 spent" as NSString
                self.contentLbl.attributedStringValue = self.addBoldText(fullString: maintext, boldPartOfString: "\(points) points" as NSString)
                self.userNameLbl.attributedStringValue = self.getAttributedString(str: text, fontSize: 12.0, isWhiteTextColor: false, isUnderLine: false, textAlignment: .right)
                self.termsTextView.textStorage?.setAttributedString(self.getAttributedString(str: details, fontSize: 11.0, isWhiteTextColor: false, isUnderLine: false, textAlignment: .natural))
                self.loginBtn.attributedTitle = self.getAttributedString(str: "TRACKING", fontSize: 14.0, isWhiteTextColor: true, isUnderLine: false, textAlignment: .center)

                self.loginBtn.image = NSImage(named: "tick")
                self.loginBtn.imagePosition = .imageLeading
                self.loginBtn.layer?.backgroundColor = NSColor(red:0.40, green:0.67, blue:0.31, alpha:1.0).cgColor
                self.loginBtn.tag = 101
                self.loginView.isHidden = false
                self.termsBtn.isHidden = false
                self.loginBtn.isHidden = false
                self.contentVerticalConstraint.constant = 10
                self.termsVerticalContraint.constant = 5
                self.termsBtnHeightConstraint.constant = 20
                self.loginBtnHeightConstraint.constant = 40
                self.preferredContentSize = NSSize(width:250, height:220)
                break
            case "LoginMerchant":
                let points = "\(currentMerchant?.rebate?.rebate_user ?? 0)"
                let details = currentMerchant?.details?.first?.info_special_terms ?? ""
                self.selectedMerchantId = currentMerchant?.merchantId ?? ""
                let maintext = "Earn \(points) points per $1 spent" as NSString
                self.contentLbl.attributedStringValue = self.addBoldText(fullString: maintext, boldPartOfString: "\(points) points" as NSString)
                self.termsTextView.textStorage?.setAttributedString(self.getAttributedString(str: details, fontSize: 11.0, isWhiteTextColor: false, isUnderLine: false, textAlignment: .natural))
                self.loginBtn.attributedTitle = self.getAttributedString(str: "LOG IN TO EARN", fontSize: 14.0, isWhiteTextColor: true, isUnderLine: false, textAlignment: .center)
                self.loginBtn.imagePosition = .noImage
                self.loginBtn.layer?.backgroundColor = NSColor(red:0.89, green:0.00, blue:0.00, alpha:1.0).cgColor
                self.loginBtn.tag = 102
                self.loginView.isHidden = true
                self.termsBtn.isHidden = false
                self.loginBtn.isHidden = false
                self.contentVerticalConstraint.constant = 5
                self.termsVerticalContraint.constant = 5
                self.termsBtnHeightConstraint.constant = 20
                self.loginBtnHeightConstraint.constant = 40
                self.preferredContentSize = NSSize(width:250, height:220)
                break
            case "Login":
                self.contentLbl.attributedStringValue = self.getAttributedString(str: "We will let you know of your next Qantas Points earning opportunity.", fontSize: 14.0, isWhiteTextColor: false, isUnderLine: false, textAlignment: .center)
                self.loginBtn.attributedTitle = self.getAttributedString(str: "LOG IN TO EARN", fontSize: 14.0, isWhiteTextColor: true, isUnderLine: false, textAlignment: .center)
                self.loginBtn.imagePosition = .noImage
                self.loginBtn.layer?.backgroundColor = NSColor(red:0.89, green:0.00, blue:0.00, alpha:1.0).cgColor
                self.loginBtn.tag = 103
                self.loginView.isHidden = true
                self.termsBtn.isHidden = true
                self.loginBtn.isHidden = false
                self.contentVerticalConstraint.constant = 5
                self.termsVerticalContraint.constant = -10
                self.termsBtnHeightConstraint.constant = 0
                self.loginBtnHeightConstraint.constant = 40
                self.preferredContentSize = NSSize(width:250, height:200)
                break
            case "Logged":
                let text = "Hi, \(token["firstName"] as! String)"
                self.userNameLbl.attributedStringValue = self.getAttributedString(str: text, fontSize: 12.0, isWhiteTextColor: false, isUnderLine: false, textAlignment: .right)

                self.contentLbl.attributedStringValue = self.getAttributedString(str: "We will let you know of your next Qantas Points earning opportunity.", fontSize: 14.0, isWhiteTextColor: false, isUnderLine: false, textAlignment: .center)
                self.loginBtn.isHidden = true
                self.loginView.isHidden = false
                self.termsBtn.isHidden = true
                self.contentVerticalConstraint.constant = 10
                self.loginBtnHeightConstraint.constant = 0
                self.termsVerticalContraint.constant = -10
                self.termsBtnHeightConstraint.constant = 0
                self.preferredContentSize = NSSize(width:250, height:165)
                break
            default:
                self.contentLbl.attributedStringValue = self.getAttributedString(str: "We will let you know of your next Qantas Points earning opportunity.", fontSize: 14.0, isWhiteTextColor: false, isUnderLine: false, textAlignment: .center)
                self.loginView.isHidden = true
                self.loginBtn.isHidden = true
                self.loginView.isHidden = false
                self.termsBtn.isHidden = true
                self.contentVerticalConstraint.constant = 5
                self.loginBtnHeightConstraint.constant = 0
                self.termsVerticalContraint.constant = -10
                self.termsBtnHeightConstraint.constant = 0
                self.preferredContentSize = NSSize(width:250, height:160)
                break
            }
        }
    }

    
    @IBAction func storeAction(_ sender: NSButton) {
        let storeUrl = Config.SHOPPING_URL_BASE + "/all-stores"
        openUrlInNewTab(urlStr: storeUrl)
    }
    
    @IBAction func faqAction(_ sender: NSButton) {
        let faqUrl = Config.SHOPPING_URL_BASE + "/faqs"
        openUrlInNewTab(urlStr: faqUrl)
    }
    
    @IBAction func termsBtnAction(_ sender: NSButton) {
        if termsView.isHidden {
            termsHeightConstraint.constant = 160
            termsView.isHidden = false
            self.preferredContentSize = NSSize(width:250, height:380)
        }else {
            termsHeightConstraint.constant = 0
            termsView.isHidden = true
            self.preferredContentSize = NSSize(width:250, height:220)
        }
    }
    
    @IBAction func closeBtnAction(_ sender: NSButton) {
        termsHeightConstraint.constant = 0
        termsView.isHidden = true
        self.preferredContentSize = NSSize(width:250, height:220)
    }
    
    @IBAction func logoutBtnAction(_ sender: Any) {
        openUrlInCurrentTab(urlStr: Config.LOGOUT_URL)
    }
    
    @IBAction func loginBtnAction(_ sender: NSButton) {
        var urlString = ""
        let tag = sender.tag
        if tag == 100 {
            urlString = Config.SHOPPING_URL_BASE + "/shop?id=" + selectedMerchantId + "&fp=true"
            openUrlInCurrentTab(urlStr: urlString)
        }else if tag == 102 {
            urlString = Config.SHOPPING_URL_BASE + "/Login/" + selectedMerchantId + "&fp=true"
            openUrlInCurrentTab(urlStr: urlString)
        }else if tag == 103 {
            urlString = Config.SHOPPING_URL_BASE + "/login/points-prompter"
            openUrlInCurrentTab(urlStr: urlString)
        }else {
            // DO NOTHING
        }
    }
    
    
    func openUrlInCurrentTab(urlStr : String) {
        SFSafariApplication.getActiveWindow { (activeWindow) in
            activeWindow?.getActiveTab(completionHandler: { (tab) in
                tab?.navigate(to: URL(string: urlStr)!)
                SafariExtensionViewController.shared.dismissPopover()
                if(urlStr == Config.LOGOUT_URL) {
                    ExtensionScript.Logout()
                }
            })
        }
    }
    
    func openUrlInNewTab(urlStr : String) {
        SFSafariApplication.getActiveWindow { (activeWindow) in
            activeWindow?.openTab(with: URL(string: urlStr)!, makeActiveIfPossible: true, completionHandler: { (_) in
                SafariExtensionViewController.shared.dismissPopover()
            })
        }
    }

    
    func getAttributedString(str: String, fontSize: CGFloat, isWhiteTextColor: Bool, isUnderLine: Bool, textAlignment: NSTextAlignment) -> NSAttributedString {
        var textColor:NSColor?
        let font:NSFont = NSFont(name: "Ciutadella-Regular", size: fontSize)!
        if isWhiteTextColor {
            textColor = NSColor.white
        }else {
            textColor = NSColor(red: 0.20, green: 0.20, blue: 0.20, alpha: 1.0)
        }
        let textParagraph:NSMutableParagraphStyle = NSMutableParagraphStyle()
        textParagraph.alignment = textAlignment
        var attribs = [NSAttributedString.Key.font: font, NSAttributedString.Key.foregroundColor : textColor!, NSAttributedString.Key.paragraphStyle : textParagraph] as [NSAttributedString.Key : Any]
        if isUnderLine {
            attribs[NSAttributedString.Key.underlineStyle] = NSUnderlineStyle.single.rawValue
        }
        let attrString:NSAttributedString = NSAttributedString.init(string: str, attributes: attribs)
        return attrString
    }

    func addBoldText(fullString: NSString, boldPartOfString: NSString) -> NSAttributedString {
        let nonBoldFontAttribute = [NSAttributedString.Key.font: NSFont(name: "Ciutadella-Regular", size: 14)!]
        let boldFontAttribute = [NSAttributedString.Key.font: NSFont(name: "Ciutadella W04 Bold", size: 14)!]
        let boldString = NSMutableAttributedString(string: fullString as String, attributes:nonBoldFontAttribute)
        boldString.addAttributes(boldFontAttribute, range: fullString.range(of: boldPartOfString as String))
        let textColor:NSColor = NSColor(red: 0.20, green: 0.20, blue: 0.20, alpha: 1.0)
        let textParagraph:NSMutableParagraphStyle = NSMutableParagraphStyle()
        textParagraph.alignment = .center

        let attribs = [NSAttributedString.Key.foregroundColor : textColor, NSAttributedString.Key.paragraphStyle : textParagraph] as [NSAttributedString.Key : Any]
        boldString.addAttributes(attribs, range: NSRange(location: 0, length: boldString.length))
        return boldString
    }
}
