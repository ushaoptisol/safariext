//
//  MerchantModel.swift
//  Qantas Extension
//
//  Created by mac05 on 23/07/19.
//  Copyright © 2019 Qantas. All rights reserved.
//

import ObjectMapper

class MerchantData: Mappable {
    var allMerchants: [Merchant]?
    var getAfLinks: [String]?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        allMerchants <- map["allMerchants"]
        getAfLinks <- map["getAfLinks"]
    }
}

class Merchant: Mappable {
    var promoted: PromotionData?
    var isVisible: Bool?
    var merchantStatus: String?
    var details: [InfoData]?
    var toolbar_permitted: Bool?
    var merchantIdOLM: Int?
    var merchantId: String?
    var websiteUrl: [String]?
    var rebate: RebateData?

    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        promoted <- map["promoted"]
        isVisible <- map["isVisible"]
        merchantStatus <- map["merchantStatus"]
        details <- map["details"]
        toolbar_permitted <- map["toolbar_permitted"]
        merchantIdOLM <- map["merchantIdOLM"]
        merchantId <- map["merchantId"]
        websiteUrl <- map["websiteUrl"]
        rebate <- map["rebate"]
    }
}

class PromotionData: Mappable {
    var prepend_special_terms: String?
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        prepend_special_terms <- map["prepend_special_terms"]
    }
}

class InfoData: Mappable {
    var info_special_terms: String?
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        info_special_terms <- map["info_special_terms"]
    }
}

class RebateData: Mappable {
    var rebate_user: Int?
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        rebate_user <- map["rebate_user"]
    }
}
