//
//  LocalStorage.swift
//  Qantas Extension
//
//  Created by mac05 on 23/07/19.
//  Copyright © 2019 Qantas. All rights reserved.
//

import Foundation
import JWTDecode
import SafariServices

let SHOW_INSTALL_PAGE = "SHO_EXT__SHOW_INSTALL_PAGE"
let STAND_DOWN_ON_LINKS = "SHO_EXT__STAND_DOWN_ON_LINKS"
let MERCHANT_DATA_KEY = "SHO_EXT__MERCHANT_DATA_KEY"
let MERCHANT_URL_MAP_KEY = "SHO_EXT__MERCHANT_URL_MAP_KEY"
let DISMISS_TIMEOUT = 2 * 60 * 60 * 1000
let TRACKING_DURATION = 2 * 60 * 60 * 1000

let IS_FIRST_TIME = "IS_FIRST_TIME"

class LocalStorage: NSObject {
    
    class func Setkey(key : String, obj : String) {
        UserDefaults.standard.set(obj, forKey: key)
    }
    
    class func Setkey_object(key : String, obj : AnyObject) {
        UserDefaults.standard.set(obj, forKey: key)
    }

    class func Getkey_object(key : String) -> AnyObject? {
        let defaults = UserDefaults.standard
        let value = defaults.object(forKey: key)
        if let actualVariable = value {
            return actualVariable as AnyObject
        }
        else{
            return nil
        }
    }

    class func Getkey(key : String) -> String {
        return UserDefaults.standard.string(forKey: key) ?? ""
    }


    
    class func MERCHANT_CLICK_DATA(merchantId : String) -> String {
        return "SHO_EXT__MERCHANT_CLICK_DATA__" + merchantId;
    }
    
    
    class func setMerchantClickData(merchantId : String, innerKey : String, value: Int64) {
        let key = MERCHANT_CLICK_DATA(merchantId: merchantId)
        
        var merchantClickData = Getkey_object(key: key) as? [String:Int64]

        let merchantObj = [innerKey : value]
        if merchantClickData != nil {
            merchantClickData?.merge(dict: merchantObj)
        }else {
            merchantClickData = merchantObj
        }
        Setkey_object(key: key, obj: merchantClickData as AnyObject)
    }
    
    class func calculateMinutesLeft(duration : Int64, timestamp : Int64) -> Int {
        let minutes = (duration - Date().getTime() - timestamp) / 1000 / 60
        return Int(minutes)
    }
    
    class func setMerchantDataToLocalStorage(data : AnyObject) {
        let keyvalue = [
            "data": data,
            "timestamp": Date().getTime()
            ] as [String : Any]
        Setkey_object(key: MERCHANT_DATA_KEY, obj: keyvalue as AnyObject)
    }

    class func setMerchantsUrlMap(data : AnyObject) {
        Setkey_object(key: MERCHANT_URL_MAP_KEY, obj: data)
    }

    class func setStandDownLinks(data : AnyObject) {
        Setkey_object(key: STAND_DOWN_ON_LINKS, obj: data)
    }

    class func setMerchantClosed(merchantId : String) {
        return setMerchantClickData(merchantId: merchantId, innerKey: "lastClosedTimestamp", value: Date().getTime())
    }
    
    class func setMerchantActivatedClicked(merchantId : String) {
        return setMerchantClickData(merchantId: merchantId, innerKey: "lastActivatedClicked", value: Date().getTime())
    }

    class func setMerchantTracking(merchantId : String) {
        return setMerchantClickData(merchantId: merchantId, innerKey: "trackingTimestamp", value: Date().getTime())
    }

    class func setAccessToken(token : String) {
        if token != "" {
            Setkey(key: Config.SHO_ACCESS_TOKEN_COOKIE_NAME, obj: token)
        }
    }

    class func getAccessToken() -> [String:AnyObject] {
        let token = Getkey(key: Config.SHO_ACCESS_TOKEN_COOKIE_NAME)
        if token != "" {
            let validated = validateToken(token: token)
            return validated
        }else {
            let tokenObj = ["firstName": "", "isValidToken" : false] as [String : Any]
            return tokenObj as [String : AnyObject]
        }
    }
    
    class func validateToken(token : String) -> [String:AnyObject] {
        let decoded = parseJwt(token: token)
        let expires = decoded["exp"] as! Int64
        let currentTime = Date().getTime() / 1000
        let tokenObj = ["firstName" : decoded["firstName"]!, "isValidToken" : expires > currentTime] as [String : Any]
        return tokenObj as [String : AnyObject]
    }

    class func getMerchantClickData(merchantId : String) -> AnyObject? {
        return Getkey_object(key: MERCHANT_CLICK_DATA(merchantId: merchantId)) ?? nil
    }

    class func getStandDownLinks() -> AnyObject? {
        return Getkey_object(key: STAND_DOWN_ON_LINKS) ?? nil
    }

    class func getMerchantDataFromLocalStorage() -> AnyObject? {
        return Getkey_object(key: MERCHANT_DATA_KEY) ?? nil
    }

    class func getMerchantsUrlMap() -> AnyObject? {
        return Getkey_object(key: MERCHANT_URL_MAP_KEY) ?? nil
    }

    class func getShowInstallPage() -> AnyObject? {
        return Getkey_object(key: SHOW_INSTALL_PAGE) ?? nil
    }
    
    class func parseJwt(token : String) -> [String:Any] {
        let jwt = try! decode(jwt: token)
        return jwt.body
    }
}

extension Dictionary {
    mutating func merge(dict: [Key: Value]){
        for (k, v) in dict {
            updateValue(v, forKey: k)
        }
    }
}

extension Date {
    func getTime() -> Int64 {
        return Int64(self.timeIntervalSince1970 * 1000)
    }
}

extension String {
    subscript(_ range: CountableRange<Int>) -> String {
        let idx1 = index(startIndex, offsetBy: max(0, range.lowerBound))
        let idx2 = index(startIndex, offsetBy: min(self.count, range.upperBound))
        return String(self[idx1..<idx2])
    }
}
