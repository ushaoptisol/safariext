//
//  SafariExtensionHandler.swift
//  Qantas Extension
//
//  Created by mac05 on 22/07/19.
//  Copyright © 2019 Qantas. All rights reserved.
//

import SafariServices

class SafariExtensionHandler: SFSafariExtensionHandler {
    override func messageReceived(withName messageName: String, from page: SFSafariPage, userInfo: [String : Any]?) {
        if messageName == "getTabUrl" {
            page.getPropertiesWithCompletionHandler { (properties) in
                let activeUrl = properties?.url?.absoluteString ?? ""
                if (activeUrl.starts(with: Config.URL_GOOGLE)) {
                    let message = ExtensionScript.GetMerchantDataForGoogle(url: activeUrl)
                    page.dispatchMessageToScript(withName: "GoogleContent", userInfo: message)
                }else {
                    if activeUrl != Config.LOGOUT_URL {
                        if (activeUrl.starts(with: Config.SHOPPING_URL_BASE) || activeUrl.starts(with: Config.QANTAS_URL)) {
                            page.dispatchMessageToScript(withName: "getCookies", userInfo: nil)
                        }
                        ExtensionScript.detectSHOTracking(activeUrl: activeUrl);
                    }
                }
            }
        }else if messageName == "tokenReceived" {
            LocalStorage.setAccessToken(token: userInfo!["token"] as! String)
        }else if messageName == "getAllUrl" {
            if !UserDefaults.standard.bool(forKey: IS_FIRST_TIME) {
                UserDefaults.standard.set(true, forKey: IS_FIRST_TIME)
                let myUrl = URL(string: "\(Config.SHOPPING_URL_BASE)/points-prompter-success")
                SFSafariApplication.getActiveWindow { (activeWindow) in
                    activeWindow?.openTab(with: myUrl!, makeActiveIfPossible: true, completionHandler: nil)
                }
                ExtensionScript.refreshData {}
            }else {
                // DO NOTHING
            }

            page.getPropertiesWithCompletionHandler { (properties) in
                let activeUrl = properties?.url?.absoluteString ?? ""
                if activeUrl != "" {
                    urlHistory.append(activeUrl)
                }
            }
        }else if messageName == "sho-notification-closed" {
            let merchantId = userInfo?["data"] as? String
            ExtensionScript.handleClosedClicked(merchantId: merchantId ?? "")
        }
    }
    
    override func validateToolbarItem(in window: SFSafariWindow, validationHandler: @escaping ((Bool, String) -> Void)) {
        window.getActiveTab { (activeTab) in
            activeTab?.getActivePage(completionHandler: { (page) in
                page?.getPropertiesWithCompletionHandler({ (properties) in
                    let activeUrl = properties?.url?.absoluteString ?? ""
                    self.handleTabActivateEvent(activeUrl: activeUrl)
                })
            })
        }
        validationHandler(true, "")
    }
        
    override func popoverViewController() -> SFSafariExtensionViewController {
        return SafariExtensionViewController.shared
    }
    
    func handleTabActivateEvent(activeUrl : String) {
        let data = ExtensionScript.onMerchantDetected(url: activeUrl)
        let merchantData = data["merchantData"] as! [String:AnyObject]
        if(merchantData["merchantId"] != nil) {
            let isDismissed = merchantData["isDismissed"] as! Bool
            let isTracking = merchantData["isTracking"] as! Bool
            let isPermitted = merchantData["isPermitted"] as! Bool
            if (isPermitted || isTracking) {
                self.updateIcon(status: "activated")
            }else {
                self.updateIcon(status: "offerAvailable")
            }
            let standDownLinks = LocalStorage.getStandDownLinks() as? [String] ?? []
            if !isDismissed {
                let shouldStandDown = standDownLinks.filter { link in
                    urlHistory.contains(where: { $0.contains(link) })}.count > 0
                if ((!shouldStandDown && isPermitted) || isTracking) {
                    SFSafariApplication.getActiveWindow { (activeWindow) in
                        activeWindow?.getActiveTab(completionHandler: { (activeTab) in
                            activeTab?.getActivePage(completionHandler: { (page) in
                                page?.dispatchMessageToScript(withName: "onMerchantDetected", userInfo: ["action" : "sho-show", "data" : data])
                            })
                        })
                    }
                }else{
                    if shouldStandDown {
                        SFSafariApplication.getActiveWindow { (window) in
                            window?.getToolbarItem(completionHandler: { (item) in
                                item?.setEnabled(false)
                            })
                        }
                    }
                }
            }
        }else {
            self.updateIcon(status: "default")
        }
        
        
    }
    
    func updateIcon(status : String) {
        var icon = NSImage(named: "ToolbarItemIcon_Default.png")
        if status == "activated" {
            icon = NSImage(named: "ToolbarItemIcon_Activated.png")
        } else if status == "offerAvailable" {
            icon = NSImage(named: "ToolbarItemIcon_OfferAvailable.png")
        }
        SFSafariApplication.getActiveWindow { (window) in
            window?.getToolbarItem(completionHandler: { (item) in
                item?.setImage(icon)
            })
        }
    }
}

